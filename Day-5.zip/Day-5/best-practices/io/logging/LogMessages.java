package com.example.io.logging;

public interface LogMessages {
	public final static String MESSAGE_FOR_SUM = "Inside CalculationService.doSum()!!";
	public final static String MESSAGE_FOR_DIFF = "Inside CalculationService.doDiff()!!";
}