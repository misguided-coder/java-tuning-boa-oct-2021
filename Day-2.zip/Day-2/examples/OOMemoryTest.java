import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class OOMemoryTest {
	
	public static void main(String[] args) throws InterruptedException  {
		
		List<String> memoryEater = new ArrayList<>();
		
		for(int i=0;i<999999999;i++) {
			memoryEater.add(new String("Memory is going to finish soon, save it - "+i));			
			TimeUnit.MILLISECONDS.sleep(200);
			System.out.println("Added one more object to memory!!!!!");
		}
		
		System.out.println("Finish Line!!!!!");
		
	}

}
